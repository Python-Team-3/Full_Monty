# Full_Monty

Team task to do in collaboration under the supervision and guidance of mentor appointed from Strypes.

The task is to develop web scraper for scraping blog posts, store the data, to manipulate the data(search, sort, etc) and then present it using front-end.

The scraping and managing the data should be created using TDD as approach.