from module.url_scraper import UrlScraper
from module.post_scraper import PostScraper
from module.post import Post
import json

if __name__ == '__main__':
    twenty_urls = UrlScraper.get_twenty_posts()
    post_scraper = PostScraper(twenty_urls)
    posts = post_scraper.get_last_posts()
    Post.print_to_file(posts)