"""
Module.

<To be updated by developer>
"""

try:
    from .example import example_function, Example
except ImportError:  # pragma: no cover
    from example import example_function, Example