"""
Example module.

<To be updated by developer>
"""


def example_function():
    """Example function.

    :returns: example string
    :rtype: str"""
    return "example function"


class Example:
    """Example class."""

    def __init__(self):
        """Initializer."""
        self.example = "example class"