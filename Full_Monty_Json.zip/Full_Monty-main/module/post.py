import json
from json import encoder
import requests
import time

class Post():
    
    def __init__(self, title, date, text, comments, common) -> None:
        self.title = title
        self.date = date
        self.text = text
        self.comments = comments
        self.common = common

    
    def print_to_file(list) -> None:
        filename = str(time.time()) +  "posts.json"
        data = {}
        data['posts'] = []
        for p in list:
            data['posts'].append({
                'title' : p.title,
                'date' : p.date,
                'text' : p.text,
                'common words' : p.common,
                'comments' : p.comments
            
            })

        with open(filename, 'a+', encoding= 'utf8') as f:

            # save the json data to a json file
            json.dump(data, f, ensure_ascii=False, indent=4, separators=(',', ': '))
        
        f.close()

